package com.cg.demo1_4;

import java.util.List;

public class Client 
{
	private List<Employee> empList;

	public Client()
	{
		
	}

	public List<Employee> getEmpList() {
		return empList;
	}

	public void setEmpList(List<Employee> empList) {
		this.empList = empList;
	}

	@Override
	public String toString() {
		return "Client [empList=" + empList + "]";
	}
	
	
	
	

}
