package com.cg.emp;

import java.util.List;

public class SBU {

	private int sbucode;
	private String sbuname;
	private String sbuhead;
	List<Employee> emplist;
	
	
	public List<Employee> getEmplist() {
		return emplist;
	}
	public void setEmplist(List<Employee> emplist) {
		this.emplist = emplist;
	}
	public int getSbucode() {
		return sbucode;
	}
	public void setSbucode(int sbucode) {
		this.sbucode = sbucode;
	}

	
	
	public String getSbuname() {
		return sbuname;
	}
	public void setSbuname(String sbuname) {
		this.sbuname = sbuname;
	}
	public String getSbuhead() {
		return sbuhead;
	}
	public void setSbuhead(String sbuhead) {
		this.sbuhead = sbuhead;
	}
	public SBU() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "SBU [sbucode=" + sbucode + ", sbuname=" + sbuname
				+ ", sbuhead=" + sbuhead + ", emplist=" + emplist + "]";
	}
	public SBU(int sbucode, String sbuname, String sbuhead,
			List<Employee> emplist) {
		super();
		this.sbucode = sbucode;
		this.sbuname = sbuname;
		this.sbuhead = sbuhead;
		this.emplist = emplist;
	}
	
	
	
	
}
