package com.cg.emp;

public class SBU {

	private int sbuId;
	private String sbuname;
	private String sbuhead;
	
	public int getSbuId() {
		return sbuId;
	}
	public void setSbuId(int sbuId) {
		this.sbuId = sbuId;
	}
	public String getSbuname() {
		return sbuname;
	}
	public void setSbuname(String sbuname) {
		this.sbuname = sbuname;
	}
	public String getSbuhead() {
		return sbuhead;
	}
	public void setSbuhead(String sbuhead) {
		this.sbuhead = sbuhead;
	}
	
	public SBU(int sbuId, String sbuname, String sbuhead) {
		super();
		this.sbuId = sbuId;
		this.sbuname = sbuname;
		this.sbuhead = sbuhead;
	}
	public SBU() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "SBU [sbuId=" + sbuId + ", sbuname=" + sbuname + ", sbuhead="
				+ sbuhead + "]";
	}
	
	
}
