package com.cg.emp;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

public class EmployeeSBUMain {
	public static void main(String args[])
	{
		XmlBeanFactory factory=new XmlBeanFactory(new ClassPathResource("anno.xml"));
	    SBU sbu=factory.getBean(SBU.class);
	    System.out.println(sbu);
	}
}
