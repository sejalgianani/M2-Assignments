package com.cg.demo1_4;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ClientMain 
{
	static String empId=null;
	static boolean flag=false;

	public static void main(String[] args)
	{
		
		ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("demo.xml");
		
		/*Client clnt=ctx.getBean(Client.class);
		
		List<Employee> emp=clnt.getEmpList();*/
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter Employee ID:");
		int inputId=sc.nextInt();
		
		/*if(inputId==100)
		{
			Client clnt=(Client) ctx.getBean("client100");
			
			List<Employee> emp=clnt.getEmpList();
				System.out.println(emp);
		}
		
		
		else 
		{
			Client clnt=(Client) ctx.getBean("client101");
			
			List<Employee> emp=clnt.getEmpList();
				System.out.println(emp);
		}*/
		
		
				try{
					empId="client"+inputId;
					Client clnt=(Client) ctx.getBean(empId);
					List<Employee> emp=clnt.getEmpList();
					System.out.println(emp);
				}
				
				catch(Exception e)
				{
					System.out.println("No Record found");
				}
			
		
	}

}
